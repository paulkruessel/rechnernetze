# Praxis 04 – auszuführende Commands und Logs

## Allgemein
Alle Logs bitte in Dateien speichern und mir danach schicken. Unter PowerShell geht das mit `Tee-Object`.

## 0) IP-Adressen für Hotspot/WLAN herausfinden

### Windows
```powershell
ipconfig
```

### Linux/macOS
```bash
ip addr
# oder:
ifconfig
```

Notiere:
- Server-IP im Hotspot/WLAN: `SERVER_HOTSPOT_IP`
- Client-IP im Hotspot/WLAN: `CLIENT_HOTSPOT_IP`

## 1) Aufgabe 3.1/3.3 – Rechenserver lokal TCP mit Threads

Terminal 1:
```powershell
python calc_server_tcp_threaded.py --ip 127.0.0.1 --port 50001 2>&1 | Tee-Object log_calc_server_tcp_local.txt
```

Terminal 2:
```powershell
python calc_client_probe.py --proto tcp --server-ip 127.0.0.1 --server-port 50001 --op SUM --numbers 1 2 3 4 5 2>&1 | Tee-Object log_calc_client_tcp_sum.txt
python calc_client_probe.py --proto tcp --server-ip 127.0.0.1 --server-port 50001 --op PRO --numbers 1 2 3 4 5 2>&1 | Tee-Object log_calc_client_tcp_pro.txt
python calc_client_probe.py --proto tcp --server-ip 127.0.0.1 --server-port 50001 --op MIN --numbers -3 8 2 10 2>&1 | Tee-Object log_calc_client_tcp_min.txt
python calc_client_probe.py --proto tcp --server-ip 127.0.0.1 --server-port 50001 --op MAX --numbers -3 8 2 10 2>&1 | Tee-Object log_calc_client_tcp_max.txt
```

Mehrere Clients gleichzeitig:
```powershell
1..5 | ForEach-Object { Start-Process powershell -ArgumentList "python calc_client_probe.py --proto tcp --server-ip 127.0.0.1 --server-port 50001 --task-id $_ --op SUM --numbers $_ 2 3" }
```

Telnet-Test:
```powershell
telnet 127.0.0.1 50001
```

## 2) Aufgabe 3.1 – Rechenserver lokal UDP

Terminal 1:
```powershell
python calc_server_udp.py --ip 127.0.0.1 --port 50002 --seconds 120 2>&1 | Tee-Object log_calc_server_udp_local.txt
```

Terminal 2:
```powershell
python calc_client_probe.py --proto udp --server-ip 127.0.0.1 --server-port 50002 --op SUM --numbers 1 2 3 4 5 2>&1 | Tee-Object log_calc_client_udp_sum.txt
```

## 3) Aufgabe 3.2 – Netzwerk-Kommunikation per Handy-Hotspot statt NordVPN

Server-Gerät im Hotspot/WLAN:
```powershell
python calc_server_tcp_threaded.py --ip SERVER_HOTSPOT_IP --port 50001 2>&1 | Tee-Object log_calc_server_tcp_hotspot.txt
```

Client-Gerät im gleichen Hotspot/WLAN:
```powershell
ping SERVER_HOTSPOT_IP
python calc_client_probe.py --proto tcp --server-ip SERVER_HOTSPOT_IP --server-port 50001 2>&1 | Tee-Object log_calc_client_tcp_hotspot_auto_port.txt
python calc_client_probe.py --proto tcp --server-ip SERVER_HOTSPOT_IP --server-port 50001 --bind-ip CLIENT_HOTSPOT_IP --bind-port 50010 2>&1 | Tee-Object log_calc_client_tcp_hotspot_bound_port.txt
```

Für die Fragen:
- `getsockname()` zeigt lokale IP und lokalen Port.
- Ohne `bind()` vergibt das Betriebssystem den lokalen Port beim `connect()` bzw. bei UDP spätestens beim ersten `sendto()`.
- Mit `sock.bind((CLIENT_HOTSPOT_IP, 50010))` setzt man lokale IP und lokalen Port selbst.
- `socket.setdefaulttimeout(5)` setzt den Default-Timeout für neu erzeugte Sockets.

## 4) Aufgabe 3.2 Frage 5 – TCP und UDP auf gleicher Portnummer

Terminal 1:
```powershell
python echo_dual_tcp_udp_server.py --ip 127.0.0.1 --port 50000 --seconds 120 2>&1 | Tee-Object log_echo_dual_server.txt
```

Terminal 2:
```powershell
python echo_client.py --proto tcp --server-ip 127.0.0.1 --server-port 50000 --message "Hello TCP" 2>&1 | Tee-Object log_echo_tcp_same_port.txt
python echo_client.py --proto udp --server-ip 127.0.0.1 --server-port 50000 --message "Hello UDP" 2>&1 | Tee-Object log_echo_udp_same_port.txt
```

## 5) Aufgabe 4 – Portscanner

Nur ausführen, wenn du im HTWG-VPN bist.

TCP 1–50:
```powershell
python port_scanner_tcp_udp.py --proto tcp --host 141.37.122.107 --start 1 --end 50 --timeout 1 --workers 50 2>&1 | Tee-Object log_scan_tcp_141_37_122_107.txt
```

UDP 1–50:
```powershell
python port_scanner_tcp_udp.py --proto udp --host 141.37.168.26 --start 1 --end 50 --timeout 1 --workers 50 2>&1 | Tee-Object log_scan_udp_141_37_168_26.txt
```

Echo-Port 7 testen:
```powershell
python echo_client.py --proto tcp --server-ip 141.37.122.107 --server-port 7 --message "Echo-Test TCP" 2>&1 | Tee-Object log_echo_remote_tcp_7.txt
python echo_client.py --proto udp --server-ip 141.37.168.26 --server-port 7 --message "Echo-Test UDP" 2>&1 | Tee-Object log_echo_remote_udp_7.txt
```

## 6) Aufgabe 5.1 – SMTP über OpenSSL

Base64 im Terminal berechnen:
```powershell
python -c "import base64; print(base64.b64encode('DEIN_USERNAME'.encode()).decode())"
python -c "import base64; print(base64.b64encode('DEIN_PASSWORT'.encode()).decode())"
```

OpenSSL starten:
```powershell
openssl s_client -starttls smtp -crlf -connect asmtp.htwg-konstanz.de:587
```

Dann interaktiv eingeben. `rcpt to` kleinschreiben:
```text
ehlo localhost
auth login
BASE64_USERNAME
BASE64_PASSWORT
mail from:<deine.htwg.adresse@htwg-konstanz.de>
rcpt to:<deine.private.zieladresse@example.com>
data
from: deine.htwg.adresse@htwg-konstanz.de
to: deine.private.zieladresse@example.com
subject: RN Labor OpenSSL Test

Dies ist eine Testmail per OpenSSL.
.
quit
```

Fake-From-Test nur an dich selbst:
```text
mail from:<beliebig@example.com>
rcpt to:<deine.private.zieladresse@example.com>
data
from: Fantasie Name <fake.absender@example.com>
to: deine.private.zieladresse@example.com
subject: RN Labor Fake From Test

Dies ist ein kontrollierter Test an mich selbst.
.
```

## 7) Aufgabe 5.2 – SMTP in Python

```powershell
python smtp_socket_client.py --username DEIN_USERNAME --from-envelope deine.htwg.adresse@htwg-konstanz.de --from-header "Dein Name <deine.htwg.adresse@htwg-konstanz.de>" --to deine.private.zieladresse@example.com --subject "RN Labor Python SMTP Test" --body "Testmail per Python-Socket" 2>&1 | Tee-Object log_smtp_python.txt
```

Fake-From-Test nur an dich selbst:
```powershell
python smtp_socket_client.py --username DEIN_USERNAME --from-envelope beliebig@example.com --from-header "Fantasie Name <fake.absender@example.com>" --to deine.private.zieladresse@example.com --subject "RN Labor Fake From Python Test" --body "Kontrollierter Test an mich selbst" 2>&1 | Tee-Object log_smtp_python_fake_from.txt
```

Wichtig: Passwort nicht in Logs kopieren. Das Skript maskiert Base64-Login/Passwortausgabe mit `***`, fragt das Passwort aber interaktiv ab.
